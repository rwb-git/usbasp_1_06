# usbasp
My repo for experimenting with the usbasp firmware from www.fischl.de
